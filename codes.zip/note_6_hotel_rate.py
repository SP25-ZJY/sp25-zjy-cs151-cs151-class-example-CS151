hotel_rate = 155
age = int(input("What is your age? "))
if age > 65:
    hotel_rate = hotel_rate - 20
print("Your rate:", hotel_rate)