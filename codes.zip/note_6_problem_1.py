print("This program will tell you if a temperature is too hot")
temp = input("What is the temperature?")
temp = float(temp)

if temp > 90:
  print("Temperature is too hot")
else:
  print("Temperature is fine")