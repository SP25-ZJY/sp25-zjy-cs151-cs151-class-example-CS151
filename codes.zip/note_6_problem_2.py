print("This will determine if you have a passing grade")

# get input
grade = float(input("What grade did you earn?"))
# make decision
if grade>=60: #COLON
  print("Booyah you passed!!")
else:
  print("We regret to inform you that you did not pass")